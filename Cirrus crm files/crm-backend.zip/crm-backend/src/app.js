const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/auth.routes");
const accountsRoutes = require("./routes/accounts.routes");
const contactsRoutes = require("./routes/contacts.routes");
const opportunitiesRoutes = require("./routes/opportunities.routes");
const leadsRoutes = require("./routes/leads.routes");
const activitiesRoutes = require("./routes/activities.routes");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/health", (req, res) => res.json({ status: "ok" }));

app.use("/api/auth", authRoutes);
app.use("/api/accounts", accountsRoutes);
app.use("/api/contacts", contactsRoutes);
app.use("/api/opportunities", opportunitiesRoutes);
app.use("/api/leads", leadsRoutes);
app.use("/api/activities", activitiesRoutes);

// 404 for anything unmatched
app.use((req, res) => {
  res.status(404).json({ error: "Not found" });
});

// Centralized error handler -- catches anything thrown/passed to next(err)
// that individual routes didn't already handle.
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

module.exports = app;
